package com.example.apbd.Fragment

interface InterfaceData {
    fun kirimData(editEdit : String)
}