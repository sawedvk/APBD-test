package com.example.apbd

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class LogoutPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.logout_page)
    }
}