package com.example.apbd

const val EXTRA_USER = "123User"

const val MEMES_NETWORK = "memes_network"

const val MEMES_DATA = "memes_data"