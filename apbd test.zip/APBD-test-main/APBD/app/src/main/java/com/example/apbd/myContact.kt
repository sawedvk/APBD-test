package com.example.apbd

data class myContact (
    var nama : String,
    var email : String,
    var nomor : String,
)