package com.example.apbd

interface MainVPInterface {
    fun hasiltujuh(model:MainModel)
    fun hasilempatbelas(model: MainModel)
    fun hasilsebulan(model: MainModel)
}