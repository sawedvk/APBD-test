package com.example.apbd

data class MainModel(
    var tujuhhari : Double = 0.0,
    var empatbelashari : Double= 0.0 ,
    var satubulan : Double = 0.0
) {
}